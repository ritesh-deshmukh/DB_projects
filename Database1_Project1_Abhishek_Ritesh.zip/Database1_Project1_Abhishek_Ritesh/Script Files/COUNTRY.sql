CREATE TABLE COUNTRY (
Country_Name Varchar(20) NOT NULL,
Population decimal(10,2),
No_of_Worldcup_won int DEFAULT 0,
Manager varchar (20),
Primary key (Country_Name) );
